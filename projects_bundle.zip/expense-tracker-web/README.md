# Expense Tracker (HTML/CSS/JS + SQL schema)
A simple expense tracker frontend that stores data in localStorage.
Includes `sql/schema.sql` with a suggested backend table design for future implementation.

**How to run**
Open `index.html` in a browser.
