const form = document.getElementById('form');
const list = document.getElementById('list');
const totalEl = document.getElementById('total');
let expenses = JSON.parse(localStorage.getItem('expenses')||'[]');
function render(){
  list.innerHTML=''; let total=0;
  expenses.forEach((e,idx)=>{
    const div = document.createElement('div'); div.className='item';
    div.innerHTML = `<div>${e.title} <small>${e.date}</small></div><div>₹${e.amount} <button data-i="${idx}">Del</button></div>`;
    list.appendChild(div);
    total += Number(e.amount);
  });
  totalEl.textContent = total;
  document.querySelectorAll('button[data-i]').forEach(b=>b.addEventListener('click',ev=>{
    const i = ev.target.dataset.i; expenses.splice(i,1); save(); render();
  }));
}
function save(){ localStorage.setItem('expenses', JSON.stringify(expenses)); }
form.addEventListener('submit', e=>{
  e.preventDefault();
  const title = document.getElementById('title').value;
  const amount = document.getElementById('amount').value;
  const date = document.getElementById('date').value;
  expenses.push({title,amount,date});
  save(); render();
  form.reset();
});
render();
