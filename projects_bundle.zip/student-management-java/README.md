# Student Management System (Java - Console)

**Description**
A simple console-based Student Management System in Java. Supports adding, listing, searching and deleting student records.

**Files**
- `src/Main.java` - Main application (uses in-memory list; optional JDBC snippets included).
- `sql/schema.sql` - SQL schema for a `students` table (MySQL/SQLite compatible).
- `README.md` - This file.
- `resume_summary.txt` - Short summary you can paste into your resume.

**How to run**
1. Compile: `javac -d bin src/Main.java`
2. Run: `java -cp bin Main`

*(Optional)*: The code contains comments showing how to replace the in-memory storage with JDBC + MySQL/SQLite.
