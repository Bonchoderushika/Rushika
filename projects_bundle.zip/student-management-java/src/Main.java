import java.util.*;
import java.io.*;
// Simple console Student Management App (in-memory)
public class Main {
    static class Student {
        int id;
        String name;
        int age;
        String email;
        Student(int id, String name, int age, String email){
            this.id=id; this.name=name; this.age=age; this.email=email;
        }
        public String toString(){ return id+": "+name+" ("+age+") - "+email; }
    }
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        List<Student> students = new ArrayList<>();
        int nextId = 1;
        while(true){
            System.out.println("\n--- Student Management ---");
            System.out.println("1. Add student\n2. List students\n3. Search by name\n4. Delete by id\n5. Save to file\n6. Load from file\n0. Exit");
            System.out.print("Choose: "); int ch = Integer.parseInt(sc.nextLine());
            if(ch==1){
                System.out.print("Name: "); String name = sc.nextLine();
                System.out.print("Age: "); int age = Integer.parseInt(sc.nextLine());
                System.out.print("Email: "); String email = sc.nextLine();
                students.add(new Student(nextId++, name, age, email));
                System.out.println("Added.");
            } else if(ch==2){
                if(students.isEmpty()) System.out.println("No students.");
                for(Student s: students) System.out.println(s);
            } else if(ch==3){
                System.out.print("Search name: "); String q=sc.nextLine().toLowerCase();
                for(Student s: students) if(s.name.toLowerCase().contains(q)) System.out.println(s);
            } else if(ch==4){
                System.out.print("Delete id: "); int id = Integer.parseInt(sc.nextLine());
                students.removeIf(s -> s.id==id);
                System.out.println("Deleted (if existed).");
            } else if(ch==5){
                try(PrintWriter pw = new PrintWriter(new FileWriter("students.txt"))){
                    for(Student s: students) pw.println(s.id+"|"+s.name+"|"+s.age+"|"+s.email);
                }
                System.out.println("Saved to students.txt");
            } else if(ch==6){
                File f = new File("students.txt");
                if(!f.exists()){ System.out.println("students.txt not found"); continue;}
                students.clear();
                try(BufferedReader br = new BufferedReader(new FileReader(f))){
                    String line; while((line=br.readLine())!=null){
                        String[] parts=line.split("\|");
                        int id=Integer.parseInt(parts[0]); String name=parts[1]; int age=Integer.parseInt(parts[2]); String email=parts[3];
                        students.add(new Student(id,name,age,email));
                        nextId = Math.max(nextId, id+1);
                    }
                }
                System.out.println("Loaded from students.txt");
            } else if(ch==0) break;
            else System.out.println("Invalid.");
        }
        sc.close();
    }
}
