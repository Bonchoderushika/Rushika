# Mini E-Commerce (HTML/CSS/JS)
Simple frontend store with product listing, search, add-to-cart and checkout (uses localStorage).

**Files**
- index.html
- css/style.css
- js/app.js
- README.md
- resume_summary.txt

**How to run**
Open `index.html` in the browser (no server required).
