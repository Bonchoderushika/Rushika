const products = [
  {id:1,name:'Classic Watch',price:999,img:''},
  {id:2,name:'Wireless Earphones',price:1499,img:''},
  {id:3,name:'Laptop Stand',price:799,img:''},
  {id:4,name:'Smartphone',price:12999,img:''}
];
const productsEl = document.getElementById('products');
const search = document.getElementById('search');
const cartCount = document.getElementById('cart-count');
const cartModal = document.getElementById('cart-modal');
const cartList = document.getElementById('cart-list');
const totalEl = document.getElementById('total');
const viewCartBtn = document.getElementById('view-cart');
const closeCartBtn = document.getElementById('close-cart');
const checkoutBtn = document.getElementById('checkout');
let cart = JSON.parse(localStorage.getItem('cart')||'[]');
function renderProducts(items){
  productsEl.innerHTML = '';
  items.forEach(p=>{
    const div = document.createElement('div'); div.className='card';
    div.innerHTML = `<img src="https://via.placeholder.com/300x140?text=${encodeURIComponent(p.name)}" alt="${p.name}">
      <h3>${p.name}</h3><p>₹${p.price}</p><button data-id="${p.id}">Add to cart</button>`;
    productsEl.appendChild(div);
  });
  productsEl.querySelectorAll('button').forEach(btn=>btn.addEventListener('click',e=>{
    const id = +e.target.dataset.id; addToCart(id);
  }));
}
function addToCart(id){
  const p = products.find(x=>x.id===id);
  const found = cart.find(x=>x.id===id);
  if(found) found.qty++;
  else cart.push({id:p.id,name:p.name,price:p.price,qty:1});
  saveCart(); renderCartCount();
}
function saveCart(){ localStorage.setItem('cart', JSON.stringify(cart)); }
function renderCartCount(){ cartCount.textContent = cart.reduce((s,i)=>s+i.qty,0); }
function openCart(){ cartModal.classList.add('show'); renderCart(); }
function closeCart(){ cartModal.classList.remove('show'); }
function renderCart(){
  cartList.innerHTML=''; let total=0;
  cart.forEach(it=>{
    const li = document.createElement('li');
    li.textContent = `${it.name} x ${it.qty} - ₹${it.price*it.qty}`;
    cartList.appendChild(li);
    total += it.price*it.qty;
  });
  totalEl.textContent = total;
}
search.addEventListener('input', ()=> renderProducts(products.filter(p=>p.name.toLowerCase().includes(search.value.toLowerCase()))));
viewCartBtn.addEventListener('click', openCart);
closeCartBtn.addEventListener('click', closeCart);
checkoutBtn.addEventListener('click', ()=>{
  alert('Checkout complete. Order placed!');
  cart = []; saveCart(); renderCartCount(); closeCart();
});
renderProducts(products); renderCartCount();
